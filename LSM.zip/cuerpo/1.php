
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://www.fismat.umich.mx/~mapeje/lsm/ESTILO1.css">
    <title>Partes del cuerpo 1</title>
</head>

<header>
    <div class="toggle-btn" onclick="myFunction();">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <a href="../cuerpo.php" class="menu-btn">&#9664;Atrás</a>
    <div class="logo">
        <p>Actividad 1: Partes del cuerpo humano en Lengua de Señas Mexicana (LSM)</p><br>
    </div>
</header>

<body>
    <div class="home-box custom-box">
        <label for="interval"><h5>Elige cuantos segundos practicarás cada una de las señas que se muestran a continuación.</h5></label>
        <input type="number" id="interval" min="1" value="10">
        <button onclick="startSlideshow()">Comenzar</button>
    </div>

    <div class="image-container">
        <div class="arrow left-arrow" id="prev-arrow">&#9664; </div>
        <img src="http://www.fismat.umich.mx/~mapeje/lsm/image/body/barba.jpg" class="image" id="current-image">
        <div class="arrow right-arrow" id="next-arrow">&#9654;</div>
    </div>

    <script>
        const images = [
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/barba.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/barbilla.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/bigote.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/boca.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/brazo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/cadera.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/cara.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/ceja.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/codo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/cuello.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/diente.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/espalda.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/estomago.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/frente.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/garganta.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/hombro.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/hueso.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/labios.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/lengua.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/mano.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/mejilla.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/muñeca.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/nariz.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/ojo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/oreja.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/pecho.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/pelo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/pestañas.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/pulgar.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/body/uña.jpg"
        ];

        let currentImageIndex = 0;
        const currentImage = document.getElementById("current-image");
        const prevArrow = document.getElementById("prev-arrow");
        const nextArrow = document.getElementById("next-arrow");

        function showImage(index) {
            currentImageIndex = index;
            currentImage.src = images[currentImageIndex];
        }

        function showNextImage() {
            currentImageIndex = (currentImageIndex + 1) % images.length;
            showImage(currentImageIndex);
        }

        function showPreviousImage() {
            if (currentImageIndex > 0) {
                currentImageIndex--;
                showImage(currentImageIndex);
            }
        }

        // flechas
        prevArrow.addEventListener("click", () => {
            showPreviousImage();
            clearInterval(intervalId);
            intervalId = setInterval(showNextImage, 10000);
        });

        nextArrow.addEventListener("click", () => {
            showNextImage();
            clearInterval(intervalId);
            intervalId = setInterval(showNextImage, 10000);
        });

        showImage(currentImageIndex);

        // intervalo para cambiar de imagen cada 10 segundos
        let intervalId = setInterval(showNextImage, 10000);

    </script>
</body>

</html>
