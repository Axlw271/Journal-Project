<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";
$user= $_POST['username'];
$pass= $_POST['password'];
$email= $_POST['email'];
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
$sql = "INSERT INTO usuarios (user, pass, email)
VALUES ('$user','$pass','$email')";
if ($conn->query($sql) === TRUE) {
  echo "<script>alert('registro exitoso')</script>";
  echo("<script>window.location = 'login.html';</script>");
} else {
  echo "<script>alert('registro fallido')</script>";
  echo("<script>window.location = 'register.html';</script>");
}
$conn->close();
?>