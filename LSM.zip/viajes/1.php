
<!DOCTYPE html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="http://www.fismat.umich.mx/~mapeje/lsm/ESTILO1.css">
	<title>Viajes 1</title>
</head>

<header>
	<div class="toggle-btn" onclick="myFunction();">
		<span></span>
		<span></span>
		<span></span>
	</div>
    <a href="../viajes.php" class="menu-btn">&#9664;Atrás</a>
	<div class="logo">
		<p>Actividad 1: Estados de la República Mexicana en Lengua de Señas Mexicana (LSM)</p><br>
	</div>  
</header>

<body>
    <div class="home-box custom-box">
        <label for="interval"><h5>Elige cuantos segundos practicarás cada una de las señas que se muestran a continuación.</h5></label>
        <input type="number" id="interval" min="1" value="10">
        <button onclick="startSlideshow()">Comenzar</button>
    </div>

	<div class="image-container">
      	 	<div class="arrow left-arrow" id="prev-arrow">&#9664; </div>
        		<img src="http://www.fismat.umich.mx/~mapeje/lsm/image/body/mexico.jpg" class="image" id="current-image">
       		<div class="arrow right-arrow" id="next-arrow">&#9654;</div>
	</div>

<script>
        const images = [
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/mexico.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/aguascalientes.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/bajacalifornia.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/bajacaliforniasur.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/campeche.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/chiapas.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/coahuila.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/colima.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/durango.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/guanajuato.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/guerrero.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/hidalgo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/jalisco.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/michoacan.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/morelos.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/nuevoleon.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/nayarit.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/oaxaca.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/puebla.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/queretaro.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/quintanaroo.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/slp.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/sinaloa.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/sonora.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/tabasco.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/tamaulipas.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/tlaxcala.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/veracruz.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/yucatan.jpg",
            "http://www.fismat.umich.mx/~mapeje/lsm/image/viajes/zacatecas.jpg"
        ];

        let currentImageIndex = 0;
                    const currentImage = document.getElementById("current-image");
                    const prevArrow = document.getElementById("prev-arrow");
                    const nextArrow = document.getElementById("next-arrow");
                    const intervalInput = document.getElementById("interval");
                    let intervalValue = parseInt(intervalInput.value) * 1000; // Convert seconds to milliseconds
                    let intervalId;
            
                    function showImage(index) {
                        currentImageIndex = index;
                        currentImage.src = images[currentImageIndex];
                    }
            
                    function showNextImage() {
                        currentImageIndex = (currentImageIndex + 1) % images.length;
                        showImage(currentImageIndex);
                    }
            
                    function showPreviousImage() {
                        if (currentImageIndex > 0) {
                            currentImageIndex--;
                            showImage(currentImageIndex);
                        }
                    }
            
                    prevArrow.addEventListener("click", () => {
                        showPreviousImage();
                        clearInterval(intervalId);
                        intervalId = setInterval(showNextImage, intervalValue);
                    });
            
                    nextArrow.addEventListener("click", () => {
                        showNextImage();
                        clearInterval(intervalId);
                        intervalId = setInterval(showNextImage, intervalValue);
                    });
            
                    function setIntervalValue() {
                        intervalValue = parseInt(intervalInput.value) * 1000;
                        clearInterval(intervalId);
                        intervalId = setInterval(showNextImage, intervalValue);
                    }
            
                    intervalInput.addEventListener("change", setIntervalValue);
            
                    function startSlideshow() {
                        clearInterval(intervalId); // Clear any existing intervals
                        intervalId = setInterval(showNextImage, intervalValue);
                    }
            
                    showImage(currentImageIndex);
                </script>
            </body>
            
            </html>